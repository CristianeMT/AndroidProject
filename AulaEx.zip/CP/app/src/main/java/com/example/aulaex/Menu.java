package com.example.aulaex;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity implements View.OnClickListener{
    TextView txtMENUser;
    ImageButton btMENContatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_xml);

        Intent tela = getIntent();
        Bundle parametros = tela.getExtras();
        String _email = parametros.getString("email");

        txtMENUser = (TextView) findViewById(R.id.txtMENUser);
        btMENContatos = (ImageButton) findViewById(R.id.btMENContatos);

        txtMENUser.setText("Usuaário : " + _email);
        btMENContatos.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent tela = new Intent(this, MainActivity.class);
        startActivity(tela);
    }
}
