package com.example.aulaex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Pedidos extends AppCompatActivity implements View.OnClickListener {
    Button btMaisSuco, btMaisDog, btMaisOvo;
    Button btMenosSuco, btMenosDog, btMenosOvo;
    Button btGravarPedido;
    TextView txtqtdOvo, txtTotalPagar, txtqtdSuco, txtqtddog;
    String _email = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_pedidos);

        Intent intencao = getIntent();
        Bundle parametros = intencao.getExtras();
        _email = parametros.getString("email");
    }

    @Override
    public void onClick(View v) {

    }
}
